# Luqman Cricket Record

**Owner:** Luqman Nazir  
**Purpose:** Live scorekeeping and records for local cricket  
**Version:** 1.0

## Run the app
Open `index.html` in a modern browser such as Chrome or Edge.

## Publish free with GitHub Pages
1. Sign in or create an account at https://github.com
2. Create a **public** repository named `luqman-cricket-record` (or `cricket-record`).
3. Upload `index.html` to the repository root and commit the file.
4. Open repository **Settings → Pages**.
5. Under Build and deployment, select **Deploy from a branch**, choose `main` and `/(root)`, then Save.
6. Wait for the published URL shown in Pages. It will look like `https://YOUR-USERNAME.github.io/luqman-cricket-record/` if you used that repository name.

## Current features
- Live team scoring: 0, 1, 2, 3, 4 and 6
- Wickets, wides, no-balls, byes and leg-byes
- Match setup with teams, date, venue and overs
- Undo the most recent scoring event
- Save match records in browser storage
- Match history, summary totals and JSON export
- Responsive layout for phones and computers

## Important limitations
Records are saved in the browser on the current device only. Scores do not yet sync between multiple phones. This starter version tracks team totals, not individual batter and bowler scorecards. For multi-device live scoring, accounts, and cloud backup, connect a backend such as Firebase or Supabase.
